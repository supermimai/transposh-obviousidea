<?php

/*
 * Transposh v1.0.14
 * http://transposh.org/
 *
 * Copyright 2026, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: 2026-10-15 candidate
 */

/*
 * This file handles various AJAX needs of our plugin
 */

echo "This file was removed in 0.8.0 and is only kept for debugging";

?>