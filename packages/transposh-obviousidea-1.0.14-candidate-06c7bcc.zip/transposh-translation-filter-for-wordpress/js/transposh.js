/*  Copyright © 2009-2025 Transposh Team (website : https://transposh.org)
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
!function(t){var e,a=t_jp.prefix,n={g:{s:1},b:{s:2},a:{s:3},y:{s:4},u:{s:5},l:{s:6}};function o(n,o){!function(e,n){if(0!==t.trim(n).length){var o=function(){var e=t(this).attr("id").substr(t(this).attr("id").lastIndexOf("_")+1),n=t("#"+a+"img_"+e);t("#"+a+e).attr("data-source",1),n.removeClass("tr-icon-yellow").removeClass("tr-icon-green").addClass("tr-icon-yellow")};e=t.escapeSelector(e),t("*[data-orig='"+e+"'][data-hidden!='y']").html(n).each(o),t("*[data-orig='"+e+"'][data-hidden='y']").attr("data-trans",n).each(o)}}(n,o),window.console&&console.log(e-t("."+a+'[data-source=""]').length+"/"+e+" auto translated")}function r(e,a,r){var s=n[e];s&&(source=s.s,function(e,a,n,o){t.ajax({url:t_jp.ajaxurl,dataType:"json",type:"GET",data:{action:"tp_tp",e:e,tl:n,q:a},success:o})}(e,r,t_jp.lang,function(t){var e;try{e=t.results}catch(t){e=[]}for(var n=0;n<e.length&&n<a.length;n++)o(a[n],e[n])}))}function s(t,e){t.length&&t_jp.preferred.some(function(a){if(t_jp.engines[a])return r(a,t,e),!0})}function i(){var e=[],n=0,o=[],r=[];t("."+a+'[data-source=""]').each(function(){var a=t(this).attr("data-orig"),i=t(this).attr("data-orig");a&&0!==a.length&&(void 0===i&&(i=t(this).html()),1!==e[i]&&(e[i]=1,n+encodeURIComponent(i).length>1024&&(s(r,o),n=0,o=[],r=[]),n+=encodeURIComponent(i).length,r.push(a),o.push(i)))}),s(r,o)}function c(e){"function"==typeof t.xLazyLoader?e():(t_jp.$=t,t.getScript(t_jp.plugin_url+"/js/lazy.js",e).done(e))}t_jp.at=i,t_jp.tfl=c,t_jp.tfju=function e(a){e.hit?a():(e.hit=!0,c(function(){t.fn.propAttr=t.fn.prop||t.fn.attr,t.xLazyLoader({js:t_jp.jQueryUI+"jquery-ui.min.js",css:t_jp.jQueryUI+"themes/"+t_jp.theme+"/jquery-ui.css",success:a})}))},t(function(){t("."+a+"setdeflang").on("click",function(){return t.ajax({url:t_jp.ajaxurl,data:{action:"tp_cookie"},cache:!1}),t("."+a+"setdeflang").hide("slow"),!1}),e=t("."+a+'[data-source=""]').length,t.ajaxSetup({cache:!0}),!e||t_jp.noauto||t.isEmptyObject(t_jp.engines)||i(),t_jp.edit&&t.getScript(t_jp.plugin_url+"/js/transposhedit.js")})}(jQuery);