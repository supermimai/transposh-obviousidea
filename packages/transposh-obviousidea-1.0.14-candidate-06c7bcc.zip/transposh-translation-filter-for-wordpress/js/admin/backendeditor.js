/*  Copyright © 2009-2018 Transposh Team (website : http://transposh.org)
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
!function(c){c(function(){c.ajaxSetup({cache:!1}),c(".delete").click(function(){var e=this,t=c(this).children().attr("href");return console.log(t),c.ajax({url:t,dataType:"json",cache:!1,success:function(t){t?c(e).parents("tr").hide():c(e).parents("tr").css("background-color","red")}}),!1})})}(jQuery);